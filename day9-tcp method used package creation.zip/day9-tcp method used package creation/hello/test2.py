import client
a=client.tcp_receive()
print(a)
