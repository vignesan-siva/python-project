import server
print(server.tcp_send("hello"))
