def tcp_send(self):
    import socket
    import sys
    sock=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    host='localhost'
    port=8080
    sock.bind((host,port))
    sock.listen(1)
    print("waiting for a connection")
    connection,client=sock.accept()
    print(client,'connected')
    data=connection.recv(16)
    print('received "%s"' % data)
    if data:
         connection.sendall(data)
    else:
         print('no data from',client)
         connection.close()
      
