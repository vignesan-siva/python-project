#km-to meter conversion
def distance(km):
    meter=km*1000
    return meter
#time hour to minites conversin
def time(hour):
    minute=hour*60
    return minute

#weight kilo to gram
def weight(kilo):
    gram=kilo*1000
    return gram
