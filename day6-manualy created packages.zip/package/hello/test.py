import convertion
print(convertion.time(45))
print(convertion.distance(34))
print(convertion.weight(56))
